﻿namespace ShowMilhao
{
    partial class FPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPergunta = new System.Windows.Forms.Label();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.pnl2 = new System.Windows.Forms.Panel();
            this.lblNumero2 = new System.Windows.Forms.Label();
            this.pnl3 = new System.Windows.Forms.Panel();
            this.lblNumero3 = new System.Windows.Forms.Label();
            this.pnl4 = new System.Windows.Forms.Panel();
            this.lblNumero4 = new System.Windows.Forms.Label();
            this.lblResp1 = new System.Windows.Forms.Label();
            this.lblResp2 = new System.Windows.Forms.Label();
            this.lblResp3 = new System.Windows.Forms.Label();
            this.lblResp4 = new System.Windows.Forms.Label();
            this.pnl1.SuspendLayout();
            this.pnl2.SuspendLayout();
            this.pnl3.SuspendLayout();
            this.pnl4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPergunta
            // 
            this.lblPergunta.BackColor = System.Drawing.Color.Teal;
            this.lblPergunta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPergunta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPergunta.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPergunta.ForeColor = System.Drawing.Color.White;
            this.lblPergunta.Location = new System.Drawing.Point(4, 4);
            this.lblPergunta.Name = "lblPergunta";
            this.lblPergunta.Size = new System.Drawing.Size(399, 136);
            this.lblPergunta.TabIndex = 0;
            this.lblPergunta.Text = "Aqui será o local onde uma pergunta será mostrada para o jogador";
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.Color.Black;
            this.pnl1.Controls.Add(this.lblNumero1);
            this.pnl1.Location = new System.Drawing.Point(4, 156);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(55, 55);
            this.pnl1.TabIndex = 1;
            // 
            // lblNumero1
            // 
            this.lblNumero1.AutoSize = true;
            this.lblNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero1.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lblNumero1.Location = new System.Drawing.Point(12, 9);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(33, 37);
            this.lblNumero1.TabIndex = 0;
            this.lblNumero1.Text = "1";
            // 
            // pnl2
            // 
            this.pnl2.BackColor = System.Drawing.Color.Black;
            this.pnl2.Controls.Add(this.lblNumero2);
            this.pnl2.Location = new System.Drawing.Point(4, 217);
            this.pnl2.Name = "pnl2";
            this.pnl2.Size = new System.Drawing.Size(55, 55);
            this.pnl2.TabIndex = 2;
            // 
            // lblNumero2
            // 
            this.lblNumero2.AutoSize = true;
            this.lblNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero2.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lblNumero2.Location = new System.Drawing.Point(12, 9);
            this.lblNumero2.Name = "lblNumero2";
            this.lblNumero2.Size = new System.Drawing.Size(35, 37);
            this.lblNumero2.TabIndex = 0;
            this.lblNumero2.Text = "2";
            // 
            // pnl3
            // 
            this.pnl3.BackColor = System.Drawing.Color.Black;
            this.pnl3.Controls.Add(this.lblNumero3);
            this.pnl3.Location = new System.Drawing.Point(4, 278);
            this.pnl3.Name = "pnl3";
            this.pnl3.Size = new System.Drawing.Size(55, 55);
            this.pnl3.TabIndex = 3;
            // 
            // lblNumero3
            // 
            this.lblNumero3.AutoSize = true;
            this.lblNumero3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero3.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lblNumero3.Location = new System.Drawing.Point(12, 9);
            this.lblNumero3.Name = "lblNumero3";
            this.lblNumero3.Size = new System.Drawing.Size(35, 37);
            this.lblNumero3.TabIndex = 0;
            this.lblNumero3.Text = "3";
            // 
            // pnl4
            // 
            this.pnl4.BackColor = System.Drawing.Color.Black;
            this.pnl4.Controls.Add(this.lblNumero4);
            this.pnl4.Location = new System.Drawing.Point(4, 339);
            this.pnl4.Name = "pnl4";
            this.pnl4.Size = new System.Drawing.Size(55, 55);
            this.pnl4.TabIndex = 4;
            // 
            // lblNumero4
            // 
            this.lblNumero4.AutoSize = true;
            this.lblNumero4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero4.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lblNumero4.Location = new System.Drawing.Point(12, 9);
            this.lblNumero4.Name = "lblNumero4";
            this.lblNumero4.Size = new System.Drawing.Size(35, 37);
            this.lblNumero4.TabIndex = 0;
            this.lblNumero4.Text = "4";
            // 
            // lblResp1
            // 
            this.lblResp1.BackColor = System.Drawing.Color.RoyalBlue;
            this.lblResp1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblResp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResp1.ForeColor = System.Drawing.Color.White;
            this.lblResp1.Location = new System.Drawing.Point(61, 156);
            this.lblResp1.Name = "lblResp1";
            this.lblResp1.Size = new System.Drawing.Size(341, 55);
            this.lblResp1.TabIndex = 5;
            this.lblResp1.Text = "Aqui será exibida uma resposta para a pergunta";
            // 
            // lblResp2
            // 
            this.lblResp2.BackColor = System.Drawing.Color.RoyalBlue;
            this.lblResp2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblResp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResp2.ForeColor = System.Drawing.Color.White;
            this.lblResp2.Location = new System.Drawing.Point(62, 217);
            this.lblResp2.Name = "lblResp2";
            this.lblResp2.Size = new System.Drawing.Size(341, 55);
            this.lblResp2.TabIndex = 6;
            this.lblResp2.Text = "Aqui será exibida uma resposta para a pergunta";
            // 
            // lblResp3
            // 
            this.lblResp3.BackColor = System.Drawing.Color.RoyalBlue;
            this.lblResp3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblResp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResp3.ForeColor = System.Drawing.Color.White;
            this.lblResp3.Location = new System.Drawing.Point(62, 278);
            this.lblResp3.Name = "lblResp3";
            this.lblResp3.Size = new System.Drawing.Size(341, 55);
            this.lblResp3.TabIndex = 7;
            this.lblResp3.Text = "Aqui será exibida uma resposta para a pergunta";
            // 
            // lblResp4
            // 
            this.lblResp4.BackColor = System.Drawing.Color.RoyalBlue;
            this.lblResp4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblResp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResp4.ForeColor = System.Drawing.Color.White;
            this.lblResp4.Location = new System.Drawing.Point(62, 339);
            this.lblResp4.Name = "lblResp4";
            this.lblResp4.Size = new System.Drawing.Size(341, 55);
            this.lblResp4.TabIndex = 8;
            this.lblResp4.Text = "Aqui será exibida uma resposta para a pergunta";
            // 
            // FPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(669, 459);
            this.Controls.Add(this.lblResp4);
            this.Controls.Add(this.lblResp3);
            this.Controls.Add(this.lblResp2);
            this.Controls.Add(this.lblResp1);
            this.Controls.Add(this.pnl4);
            this.Controls.Add(this.pnl3);
            this.Controls.Add(this.pnl2);
            this.Controls.Add(this.pnl1);
            this.Controls.Add(this.lblPergunta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PREVE AGUDOS - Show do Milhão [3º Ano - Técnico em Informática 2025]";
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.pnl2.ResumeLayout(false);
            this.pnl2.PerformLayout();
            this.pnl3.ResumeLayout(false);
            this.pnl3.PerformLayout();
            this.pnl4.ResumeLayout(false);
            this.pnl4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblPergunta;
        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Panel pnl2;
        private System.Windows.Forms.Label lblNumero2;
        private System.Windows.Forms.Panel pnl3;
        private System.Windows.Forms.Label lblNumero3;
        private System.Windows.Forms.Panel pnl4;
        private System.Windows.Forms.Label lblNumero4;
        private System.Windows.Forms.Label lblResp1;
        private System.Windows.Forms.Label lblResp2;
        private System.Windows.Forms.Label lblResp3;
        private System.Windows.Forms.Label lblResp4;
    }
}

